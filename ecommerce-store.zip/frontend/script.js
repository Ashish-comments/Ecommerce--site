fetch('http://localhost:5000/api/products')
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById('products');
    data.forEach(p => {
      const div = document.createElement('div');
      div.innerHTML = `<h3>${p.name}</h3><p>${p.price}</p>`;
      container.appendChild(div);
    });
  });