const express = require('express');
const router = express.Router();

// Define routes here

module.exports = router;
