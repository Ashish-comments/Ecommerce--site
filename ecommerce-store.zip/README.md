# Simple E-commerce Store

A basic store built with HTML/CSS/JS and Express.js backend.